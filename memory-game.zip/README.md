# Memory Game

A customizable card-matching memory game built with vanilla HTML, CSS, and JavaScript. Flip cards, find matching pairs, and challenge yourself across different grid sizes and themes.

## Features

- **4 emoji themes** — Animals, Food, Sports, Objects
- **Flexible grid size** — separate Rows and Columns inputs (3-7 each), any combination
- **Dark / light mode** toggle
- **Move counter** and **timer**
- **Star rating** (3-star system based on efficiency)
- **Win modal** with final stats and play-again option
- **Card flip & shake animations**

## How to Play

Open `index.html` directly in your browser, or use any static file server:

```bash
npx serve .
# or
python -m http.server 8000
```

Click cards to flip them. Match all pairs to win. Fewer moves = more stars.

## Customization

Use the dropdown in the header to switch **theme** (emoji set) and the number inputs to set **rows** and **columns** (3-7 each) at any time — the game restarts automatically. Odd total cell counts get one empty placeholder cell.

## Tech Stack

Vanilla HTML, CSS, and JavaScript. No frameworks, no build tools, no dependencies.
